# ![Merge Objects icon](images/icons/Object_Merge.png) Merge Objects

Merges two or more selected ProBuilder GameObjects into a single ProBuilder GameObject. 

> ***Warning:*** If you merge two objects that intersect, the new object may have overlapping UVs.

