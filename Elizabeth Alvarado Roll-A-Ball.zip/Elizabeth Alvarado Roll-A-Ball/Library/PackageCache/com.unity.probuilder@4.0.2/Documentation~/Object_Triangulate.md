# ![Triangulate icon](images/icons/Object_Triangulate.png) Triangulate (Objects)

Reduces all polygons to their base triangles, creating a sharp, faceted appearance.

![Triangulate Object Example](images/TriangulateObject_Example.png)

