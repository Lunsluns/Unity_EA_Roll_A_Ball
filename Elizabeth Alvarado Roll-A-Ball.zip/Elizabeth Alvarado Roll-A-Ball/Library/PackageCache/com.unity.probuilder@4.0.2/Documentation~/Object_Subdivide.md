# ![Subdivide Object icon](images/icons/Object_Subdivide.png) Subdivide Object

Divides every face on selected objects, allowing for greater levels of detail when modeling.

![Subdivide Object Example](images/SubdivideObject_Example.png)

